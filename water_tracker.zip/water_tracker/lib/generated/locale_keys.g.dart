// DO NOT EDIT. This is code generated via package:easy_localization/generate.dart

abstract class  LocaleKeys {
  static const enter_your_email = 'enter_your_email';
  static const enter_password = 'enter_password';
  static const sign_in = 'sign_in';
  static const welcome_back_tony = 'welcome_back_tony';
  static const dont_have_an_account_yet = 'dont_have_an_account_yet';
  static const sign_up = 'sign_up';
  static const by_signing_in_you_agree_to_our = 'by_signing_in_you_agree_to_our';
  static const terms = 'terms';
  static const and = 'and';
  static const privacy_policy = 'privacy_policy';
  static const please_enter_email = 'please_enter_email';
  static const please_enter_correct_email = 'please_enter_correct_email';
  static const please_enter_password = 'please_enter_password';
  static const invalid_password = 'invalid_password';
  static const start_your_journey = 'start_your_journey';
  static const re_enter_your_password = 're_enter_your_password';
  static const passwords_do_not_match_try_again = 'passwords_do_not_match_try_again';
  static const already_have_an_account = 'already_have_an_account';
  static const skip = 'skip';
  static const tell_more_general_info = 'tell_more_general_info';
  static const password_must_contain_at_least_8_characters = 'password_must_contain_at_least_8_characters';
  static const setup_profile = 'setup_profile';
  static const password_must_contain_one_uppercase_letter = 'password_must_contain_one_uppercase_letter';
  static const error_try_again = 'error_try_again';
  static const sex = 'sex';
  static const man = 'man';
  static const woman = 'woman';
  static const age = 'age';
  static const weight = 'weight';
  static const next = 'next';
  static const please_fill_in_general_information = 'please_fill_in_general_information';
  static const what_is_your_goal = 'what_is_your_goal';
  static const drink_more_water = 'drink_more_water';
  static const lose_weight = 'lose_weight';
  static const shine_skin = 'shine_skin';
  static const lead_a_healthy_lifestyle = 'lead_a_healthy_lifestyle';
  static const improve_digestion = 'improve_digestion';
  static const another = 'another';
  static const failed_store = 'failed_store';
  static const manage_water_title = 'manage_water_title';
  static const description = 'description';
  static const notification_text = 'notification_text';
  static const every_hour = 'every_hour';
  static const every_two_hours = 'every_two_hours';
  static const get_started = 'get_started';
  static const you_already_got = 'you_already_got';
  static const cups = 'cups';
  static const ml = 'ml';
  static const failed_to_increment_count = 'failed_to_increment_count';

}
