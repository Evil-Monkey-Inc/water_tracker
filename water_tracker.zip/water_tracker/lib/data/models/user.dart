class User {
  User(
    this.email, {
    this.username,
  });
  final String email;
  final String? username;
}
