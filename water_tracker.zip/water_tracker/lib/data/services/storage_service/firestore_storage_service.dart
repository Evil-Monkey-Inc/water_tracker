import 'package:water_tracker/data/services/storage_service/storage_service.dart';

abstract class FireStoreStorageService implements StorageService {}
